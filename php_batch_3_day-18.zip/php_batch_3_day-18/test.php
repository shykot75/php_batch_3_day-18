<?php

session_start();

$name = "BITM";

$_SESSION['name'] = $name;