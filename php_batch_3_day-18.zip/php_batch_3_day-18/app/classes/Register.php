<?php


namespace App\classes;


class Register
{
    public function __construct($post=null)
    {
        echo "<pre>";
        print_r($post);
    }
}